CREATE DATABASE  IF NOT EXISTS `rsinfo_p` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `rsinfo_p`;
-- MySQL dump 10.13  Distrib 5.6.18, for Win32 (x86)
--
-- Host: localhost    Database: rsinfo_p
-- ------------------------------------------------------
-- Server version	5.6.18-enterprise-commercial-advanced

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_power`
--

DROP TABLE IF EXISTS `admin_power`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_power` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '权限编号',
  `name` varchar(255) DEFAULT NULL COMMENT '权限名称',
  `type` varchar(1) DEFAULT NULL COMMENT '权限类型',
  `code` varchar(30) DEFAULT NULL COMMENT '权限标识',
  `url` varchar(255) DEFAULT NULL COMMENT '权限路径',
  `open_type` varchar(10) DEFAULT NULL COMMENT '打开方式',
  `parent_id` int(11) DEFAULT NULL COMMENT '父类编号',
  `icon` varchar(128) DEFAULT NULL COMMENT '图标',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `enable` int(11) DEFAULT NULL COMMENT '是否开启',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_power`
--

LOCK TABLES `admin_power` WRITE;
/*!40000 ALTER TABLE `admin_power` DISABLE KEYS */;
INSERT INTO `admin_power` VALUES (1,'系统管理','0','',NULL,NULL,0,'layui-icon layui-icon-set-fill',1,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(3,'用户管理','1','admin:user:main','/admin/user/','_iframe',1,'layui-icon layui-icon layui-icon layui-icon layui-icon-rate',1,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(4,'权限管理','1','admin:power:main','/admin/power/','_iframe',1,NULL,2,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(9,'角色管理','1','admin:role:main','/admin/role','_iframe',1,'layui-icon layui-icon-username',2,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(12,'系统监控','1','admin:monitor:main','/admin/monitor','_iframe',1,'layui-icon layui-icon-vercode',5,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(13,'日志管理','1','admin:log:main','/admin/log','_iframe',1,'layui-icon layui-icon-read',4,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(17,'文件管理','0','','','',0,'layui-icon layui-icon-camera',2,'2023-05-31 17:21:50','2023-06-01 13:29:31',0),(18,'图片上传','1','admin:file:main','/admin/file','_iframe',17,'layui-icon layui-icon-camera',5,'2023-05-31 17:21:50','2023-06-01 13:29:46',1),(21,'权限增加','2','admin:power:add','','',4,'layui-icon layui-icon-add-circle',1,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(22,'用户增加','2','admin:user:add','','',3,'layui-icon layui-icon-add-circle',1,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(23,'用户编辑','2','admin:user:edit','','',3,'layui-icon layui-icon-rate',2,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(24,'用户删除','2','admin:user:remove','','',3,'',3,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(25,'权限编辑','2','admin:power:edit','','',4,'',2,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(26,'用户删除','2','admin:power:remove','','',4,'',3,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(27,'用户增加','2','admin:role:add','','',9,'',1,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(28,'角色编辑','2','admin:role:edit','','',9,'',2,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(29,'角色删除','2','admin:role:remove','','',9,'',3,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(30,'角色授权','2','admin:role:power','','',9,'',4,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(31,'图片增加','2','admin:file:add','','',18,'',1,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(32,'图片删除','2','admin:file:delete','','',18,'',2,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(44,'数据字典','1','admin:dict:main','/admin/dict','_iframe',1,'layui-icon layui-icon-console',6,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(45,'字典增加','2','admin:dict:add','','',44,'',1,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(46,'字典修改','2','admin:dict:edit','','',44,'',2,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(47,'字典删除','2','admin:dict:remove','','',44,'',3,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(48,'部门管理','1','admin:dept:main','/dept','_iframe',1,'layui-icon layui-icon-group',3,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(49,'部门增加','2','admin:dept:add','','',48,'',1,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(50,'部门编辑','2','admin:dept:edit','','',48,'',2,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(51,'部门删除','2','admin:dept:remove','','',48,'',3,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(57,'邮件管理','1','admin:mail:main','/admin/mail','_iframe',1,'layui-icon ',7,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(58,'邮件发送','2','admin:mail:add','','',57,'layui-icon layui-icon-ok-circle',1,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(59,'邮件删除','2','admin:mail:remove','','',57,'',2,'2023-05-31 17:21:50','2023-05-31 17:21:50',1),(60,'业务处理','0',NULL,NULL,NULL,0,'layui-icon layui-icon layui-icon-note',3,'2023-06-01 13:29:03','2023-07-06 13:30:48',1),(61,'销售订单','1','admin:sell:main','/bus/sell/','_iframe',60,'layui-icon layui-icon layui-icon layui-icon layui-icon layui-icon layui-icon ',1,'2023-06-01 13:34:47','2023-06-22 22:06:41',1),(62,'订单增加','2','admin:sell:add',NULL,NULL,61,'layui-icon layui-icon layui-icon layui-icon layui-icon ',1,'2023-06-01 13:39:03','2023-06-01 16:06:48',1),(63,'订单编辑','2','admin:sell:edit',NULL,NULL,61,'layui-icon layui-icon layui-icon ',2,'2023-06-01 13:40:33','2023-06-01 15:14:36',1),(64,'订单删除','2','admin:sell:remove',NULL,NULL,61,'layui-icon layui-icon ',3,'2023-06-01 13:41:50','2023-06-01 15:14:48',1),(65,'订单明细','2','admin:sell:detail',NULL,NULL,61,'layui-icon layui-icon-circle-dot',4,'2023-06-05 10:22:33','2023-06-05 10:35:17',1),(66,'订单明细添加','2','admin:sell:detail:add',NULL,NULL,65,'layui-icon ',5,'2023-06-05 14:31:40','2023-06-05 14:31:40',1),(67,'订单明细修改','2','admin:sell:detail:edit',NULL,NULL,65,'layui-icon ',6,'2023-06-05 14:32:27','2023-06-05 14:32:27',1),(68,'订单明细删除','2','admin:sell:detail:remove',NULL,NULL,65,'layui-icon ',7,'2023-06-05 14:32:49','2023-06-05 14:32:49',1),(69,'联系人管理','1','bus:contact:main','/bus/contact/','_iframe',60,'layui-icon layui-icon layui-icon ',2,'2023-07-06 13:31:41','2023-07-06 16:19:16',1),(70,'联系人添加','2','bus:contact:add',NULL,NULL,69,'layui-icon layui-icon ',1,'2023-07-06 16:13:35','2023-07-06 16:19:30',1),(71,'联系人编辑','2','bus:contact:edit',NULL,NULL,69,'layui-icon layui-icon layui-icon ',2,'2023-07-06 16:14:35','2023-07-06 16:19:49',1),(72,'联系人删除','2','bus:contact:remove',NULL,NULL,69,'layui-icon layui-icon layui-icon ',3,'2023-07-06 16:15:46','2023-07-06 16:20:02',1),(73,'物料分类','1','bus:materialcategory:main','/bus/materialcategory/','_iframe',60,'layui-icon layui-icon layui-icon ',3,'2023-07-07 10:09:40','2023-07-07 10:12:48',1),(74,'物料分类增加','2','bus:materialcategory:add',NULL,NULL,73,'layui-icon layui-icon ',1,'2023-07-07 10:14:06','2023-07-07 10:15:20',1),(75,'物料分类编辑','2','bus:materialcategory:edit',NULL,NULL,73,'layui-icon ',2,'2023-07-07 10:14:46','2023-07-07 10:14:46',1),(76,'物料分类删除','2','bus:materialcategory:remove',NULL,NULL,73,'layui-icon ',3,'2023-07-07 10:15:52','2023-07-07 10:15:52',1),(77,'物料管理','1','bus:material:main','/bus/material/','_iframe',60,'layui-icon layui-icon ',4,'2023-07-07 16:06:38','2023-07-07 16:07:05',1);
/*!40000 ALTER TABLE `admin_power` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-25 17:30:04
