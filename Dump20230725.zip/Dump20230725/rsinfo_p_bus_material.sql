CREATE DATABASE  IF NOT EXISTS `rsinfo_p` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `rsinfo_p`;
-- MySQL dump 10.13  Distrib 5.6.18, for Win32 (x86)
--
-- Host: localhost    Database: rsinfo_p
-- ------------------------------------------------------
-- Server version	5.6.18-enterprise-commercial-advanced

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bus_material`
--

DROP TABLE IF EXISTS `bus_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bus_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '物料ID',
  `name` varchar(255) DEFAULT NULL COMMENT '物料名称',
  `detail` varchar(255) DEFAULT NULL COMMENT '物料说明',
  `category` int(11) DEFAULT NULL COMMENT '分类',
  `barcode` varchar(255) DEFAULT NULL COMMENT '条码',
  `cost` varchar(255) DEFAULT NULL COMMENT '成本',
  `price` varchar(255) DEFAULT NULL COMMENT '价格',
  `unit` varchar(255) DEFAULT NULL COMMENT '单位',
  `threshold` varchar(255) DEFAULT NULL COMMENT '提醒门限',
  `vendor` varchar(255) DEFAULT NULL COMMENT '供应商',
  `manufacturer` varchar(255) DEFAULT NULL COMMENT '制造商',
  `mpq` int(11) DEFAULT NULL COMMENT '最小包装数量',
  `moq` int(11) DEFAULT NULL COMMENT '最小起订量',
  `virtual` int(11) DEFAULT NULL COMMENT '虚拟物料',
  `highlight` int(11) DEFAULT NULL COMMENT '重点关注',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus_material`
--

LOCK TABLES `bus_material` WRITE;
/*!40000 ALTER TABLE `bus_material` DISABLE KEYS */;
INSERT INTO `bus_material` VALUES (3,'aa','',8,'','','','','','','',1,0,0,1,'','2023-07-19 21:03:59','2023-07-23 18:48:34'),(4,'bb','',8,'','','','','','','',1,0,1,1,'','2023-07-19 21:16:50','2023-07-23 18:57:43'),(5,'cc','',9,'','','','','','','',1,0,1,0,'','2023-07-23 17:42:09','2023-07-23 19:04:07'),(6,'dd','',1,'','','','','','','',1,0,0,1,'','2023-07-23 18:50:16','2023-07-23 18:57:04');
/*!40000 ALTER TABLE `bus_material` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-25 17:30:02
