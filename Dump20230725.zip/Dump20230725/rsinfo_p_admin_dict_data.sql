CREATE DATABASE  IF NOT EXISTS `rsinfo_p` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `rsinfo_p`;
-- MySQL dump 10.13  Distrib 5.6.18, for Win32 (x86)
--
-- Host: localhost    Database: rsinfo_p
-- ------------------------------------------------------
-- Server version	5.6.18-enterprise-commercial-advanced

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_dict_data`
--

DROP TABLE IF EXISTS `admin_dict_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_dict_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_label` varchar(255) DEFAULT NULL COMMENT '字典类型名称',
  `data_value` varchar(255) DEFAULT NULL COMMENT '字典类型标识',
  `type_code` varchar(255) DEFAULT NULL COMMENT '字典类型描述',
  `is_default` int(11) DEFAULT NULL COMMENT '是否默认',
  `enable` int(11) DEFAULT NULL COMMENT '是否开启',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_dict_data`
--

LOCK TABLES `admin_dict_data` WRITE;
/*!40000 ALTER TABLE `admin_dict_data` DISABLE KEYS */;
INSERT INTO `admin_dict_data` VALUES (1,'客户','1','relation',NULL,1,NULL,'2023-06-24 19:43:38','2023-06-24 19:43:38'),(2,'供应商','2','relation',NULL,1,NULL,'2023-06-24 19:43:49','2023-06-24 19:43:53'),(3,'其他','3','relation',NULL,1,NULL,'2023-06-24 19:44:11','2023-06-24 19:44:11');
/*!40000 ALTER TABLE `admin_dict_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-25 17:30:04
